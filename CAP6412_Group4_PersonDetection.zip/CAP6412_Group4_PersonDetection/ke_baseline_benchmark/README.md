# Person Detection Benchmark on PersonPath22

Condition-stratified evaluation of YOLOv8m, RT-DETR, and Faster R-CNN for person detection in surveillance video.

Course project for [CAP6412], [Spring 2026].

## Overview

Existing object detectors are widely deployed for person detection, but there is no benchmark evaluating how they perform across different real-world video conditions. This project builds a condition-stratified benchmark using PersonPath22, evaluating three detector architectures across 190 videos (27,470 frames, 531,380 person annotations) stratified by four axes:

- **Density**: sparse / moderate / crowded
- **Environment**: indoor / outdoor
- **Lighting**: bright / dark
- **Camera angle**: high / mid / low

## Key findings

1. **Faster R-CNN wins on all conditions** (mAP 0.397), but runs slower (20.3 FPS)
2. **YOLOv8m is fastest** (25.5 FPS) with mAP 0.358 — 10% lower than Faster R-CNN
3. **Faster R-CNN degrades least in crowded scenes** (14% drop sparse→crowded, vs ~20% for others)
4. **Low camera angle performs best** across all detectors — counterintuitive but consistent
5. **Night ≈ Day performance** — likely due to PersonPath22's well-lit urban night footage

## Results summary

| Detector | mAP | mAP@0.5 | mAP@0.75 | FPS |
|----------|------|---------|----------|-----|
| YOLOv8m | 0.358 | 0.512 | 0.394 | 25.51 |
| RT-DETR | 0.371 | 0.572 | 0.397 | 18.17 |
| Faster R-CNN | **0.397** | **0.651** | **0.423** | 20.30 |

See `results/` for per-condition breakdowns.

## Dataset

PersonPath22 (Amazon/FAIR, ECCV 2022): 190 videos from the full 236-video set.
- Resolution: mostly 1080p, some 4K and 720p
- Frame rate: 24-60 fps
- Length: 10-168 seconds per video
- Annotations: ~5 fps sampling, human-verified person bounding boxes (reflections filtered out)

Source: https://github.com/amazon-science/tracking-dataset

## Pipeline

1. **Extract frames** that have person annotations
2. **Convert** PersonPath22 JSON annotations to COCO format
3. **Run detectors** (YOLOv8m, RT-DETR, Faster R-CNN) on extracted frames
4. **Evaluate** using pycocotools, stratified by taxonomy

## Usage

### Setup
```bash
pip install ultralytics torch torchvision pycocotools opencv-python pandas numpy
```

### Run full pipeline
```bash
# 1. Extract frames with annotations
python src/extract_annotated_frames.py \
    --video_dir /path/to/raw_data \
    --annotation_dir /path/to/anno_visible_2022 \
    --video_list data/video_list.txt \
    --out_dir data/frames

# 2. Build ground truth in COCO format
python src/personpath_json_to_coco.py \
    --annotation_dir /path/to/anno_visible_2022 \
    --frames_dir data/frames \
    --out_file data/gt_coco.json

# 3. Run detectors
python src/run_detectors.py --frames_dir data/frames --out_dir data/results --detector yolov8m
python src/run_detectors.py --frames_dir data/frames --out_dir data/results --detector rtdetr
python src/run_detectors.py --frames_dir data/frames --out_dir data/results --detector fasterrcnn

# 4. Evaluate per condition
python src/evaluate.py --gt data/gt_coco.json --pred data/results/yolov8m_predictions.json \
    --taxonomy data/taxonomy.csv --out data/results/eval_yolov8m.json
# (repeat for rtdetr and fasterrcnn)
```

## Repository structure

```
.
├── src/                           # Scripts
│   ├── extract_annotated_frames.py
│   ├── personpath_json_to_coco.py
│   ├── run_detectors.py
│   └── evaluate.py
├── data/
│   ├── taxonomy.csv               # Per-video condition tags
│   └── video_list.txt             # List of 190 video filenames
├── results/
│   ├── eval_yolov8m.json          # Per-condition mAP, YOLOv8m
│   ├── eval_rtdetr.json           # Per-condition mAP, RT-DETR
│   └── eval_fasterrcnn.json       # Per-condition mAP, Faster R-CNN
└── README.md
```

## Limitations

- PersonPath22 night videos are primarily well-lit urban scenes (no truly dark footage)
- Per-condition sample sizes vary (30-152 videos per group); smaller conditions have wider confidence intervals
- Single-annotator taxonomy labels (no inter-annotator agreement measured)
- COCO-pretrained detectors evaluated zero-shot (no fine-tuning on PersonPath22)
- Density and person-scale are partially confounded in the dataset



