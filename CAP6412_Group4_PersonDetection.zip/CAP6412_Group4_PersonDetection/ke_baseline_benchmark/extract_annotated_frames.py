"""
Extract frames that correspond to PersonPath22 JSON annotation frame_idx values.
This ensures perfect alignment between extracted frames and ground truth.

Usage:
    python extract_annotated_frames.py \
        --video_dir /path/to/videos \
        --annotation_dir /path/to/personpath22_json_annotations \
        --video_list data/video_list.txt \
        --out_dir data/frames
"""
import argparse
import json
from pathlib import Path
import cv2


def load_annotated_frame_indices(ann_file: Path, person_only: bool = True):
    """Return set of frame indices that have annotations in this video."""
    with open(ann_file) as f:
        data = json.load(f)
    indices = set()
    for e in data['entities']:
        if person_only and 'person' not in e.get('labels', {}):
            continue
        indices.add(e['blob']['frame_idx'])
    return sorted(indices)


def extract_frames(video_path: Path, frame_indices: list, out_dir: Path):
    """Extract specific frames from a video using frame indices."""
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        print(f"[ERROR] Could not open {video_path}")
        return 0

    video_stem = video_path.stem
    video_out_dir = out_dir / video_stem
    video_out_dir.mkdir(parents=True, exist_ok=True)

    # Read sequentially and skip to target frames (more reliable than random seeking)
    target_set = set(frame_indices)
    max_idx = max(frame_indices) if frame_indices else 0

    extracted = 0
    current_idx = 0
    while current_idx <= max_idx:
        ret, frame = cap.read()
        if not ret:
            break
        if current_idx in target_set:
            out_path = video_out_dir / f"{video_stem}_f{current_idx:06d}.jpg"
            cv2.imwrite(str(out_path), frame, [cv2.IMWRITE_JPEG_QUALITY, 95])
            extracted += 1
        current_idx += 1

    cap.release()
    return extracted


def find_annotation_file(ann_dir: Path, video_stem: str):
    """Find the JSON annotation file for a video. Handles naming variations."""
    candidates = [
        ann_dir / f"{video_stem}.json",
        ann_dir / f"{video_stem}_mp4.json",
        ann_dir / f"{video_stem}.mp4.json",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--video_dir", required=True)
    ap.add_argument("--annotation_dir", required=True)
    ap.add_argument("--video_list", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--person_only", action="store_true", default=True)
    args = ap.parse_args()

    video_dir = Path(args.video_dir)
    ann_dir = Path(args.annotation_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    with open(args.video_list) as f:
        video_files = [line.strip() for line in f if line.strip()]

    total = 0
    missing = []
    for vf in video_files:
        vp = video_dir / vf
        if not vp.exists():
            print(f"[SKIP] Video missing: {vp}")
            continue

        video_stem = vp.stem
        ann_file = find_annotation_file(ann_dir, video_stem)
        if ann_file is None:
            print(f"[SKIP] No annotation file for {video_stem}")
            missing.append(video_stem)
            continue

        indices = load_annotated_frame_indices(ann_file, args.person_only)
        n = extract_frames(vp, indices, out_dir)
        print(f"{vf}: {n} frames extracted (from {len(indices)} annotated)")
        total += n

    print(f"\nTotal frames extracted: {total}")
    if missing:
        print(f"Missing annotations for: {missing}")


if __name__ == "__main__":
    main()