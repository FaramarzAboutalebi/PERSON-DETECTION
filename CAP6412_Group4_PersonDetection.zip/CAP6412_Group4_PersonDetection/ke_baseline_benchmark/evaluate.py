"""
Evaluate detector predictions against ground truth with per-condition breakdown.

Usage:
    python evaluate.py --gt gt_coco.json --pred yolov8m_predictions.json \
        --taxonomy taxonomy.csv --out results_yolov8m.json
"""
import argparse
import json
from pathlib import Path
from collections import defaultdict

import pandas as pd


def load_preds_as_coco_format(pred_file):
    """Convert our prediction file to the flat COCO eval format."""
    with open(pred_file) as f:
        data = json.load(f)
    return data["predictions"], data.get("fps", None), data.get("detector", "unknown")


def run_coco_eval(gt_file, pred_list, image_ids=None):
    """Run COCO evaluation on a specific image subset if image_ids given."""
    from pycocotools.coco import COCO
    from pycocotools.cocoeval import COCOeval

    coco_gt = COCO(gt_file)
    if not pred_list:
        return None
    coco_dt = coco_gt.loadRes(pred_list)
    ev = COCOeval(coco_gt, coco_dt, "bbox")
    if image_ids is not None:
        ev.params.imgIds = list(image_ids)
    ev.evaluate()
    ev.accumulate()
    ev.summarize()

    return {
        "AP": float(ev.stats[0]),
        "AP50": float(ev.stats[1]),
        "AP75": float(ev.stats[2]),
        "AP_small": float(ev.stats[3]),
        "AP_medium": float(ev.stats[4]),
        "AP_large": float(ev.stats[5]),
        "AR_100": float(ev.stats[8]),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gt", required=True, help="Ground truth COCO JSON")
    ap.add_argument("--pred", required=True, help="Prediction JSON from run_detectors.py")
    ap.add_argument("--taxonomy", required=True,
                    help="CSV with columns: video_id, density, lighting, environment, ...")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    predictions, fps, detector_name = load_preds_as_coco_format(args.pred)

    # Overall
    print(f"\n=== Overall ({detector_name}) ===")
    overall = run_coco_eval(args.gt, predictions)

    # Per-condition breakdown
    with open(args.gt) as f:
        gt_data = json.load(f)
    # Map image_id -> video_name
    img_to_video = {img["id"]: img["video"] for img in gt_data["images"]}

    # Load taxonomy
    tax = pd.read_csv(args.taxonomy)
    # Expect column named video_id (matches the folder name, e.g. uid_vid_00000)
    video_to_attrs = tax.set_index("video_id").to_dict(orient="index")

    # For each attribute column, group videos and eval
    attr_cols = [c for c in tax.columns if c != "video_id"]
    per_condition_results = {}

    for attr in attr_cols:
        per_condition_results[attr] = {}
        # Group videos by value of this attribute
        groups = defaultdict(list)
        for vid, attrs in video_to_attrs.items():
            groups[attrs[attr]].append(vid)

        for val, video_list in groups.items():
            # Get all image_ids for these videos
            img_ids = {iid for iid, vname in img_to_video.items() if vname in video_list}
            if not img_ids:
                continue
            print(f"\n=== {attr}={val} ({len(video_list)} videos, {len(img_ids)} frames) ===")
            try:
                result = run_coco_eval(args.gt, predictions, image_ids=img_ids)
                per_condition_results[attr][str(val)] = {
                    "n_videos": len(video_list),
                    "n_frames": len(img_ids),
                    **(result or {}),
                }
            except Exception as e:
                print(f"  Eval failed: {e}")

    # Save
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    with open(args.out, "w") as f:
        json.dump({
            "detector": detector_name,
            "fps": fps,
            "overall": overall,
            "per_condition": per_condition_results,
        }, f, indent=2)
    print(f"\nSaved to {args.out}")


if __name__ == "__main__":
    main()