"""
Convert PersonPath22 JSON annotations to COCO format for evaluation.

PersonPath22 annotation format (per-video JSON):
{
  "metadata": {"fps": ..., "number_of_frames": ..., "resolution": {...}, ...},
  "entities": [
    {"bb": [x, y, w, h], "blob": {"frame_idx": N}, "id": ..., "labels": {"person": 1}, ...}
  ]
}

Output: COCO-format JSON matching the extracted frames.

Usage:
    python personpath_json_to_coco.py \
        --annotation_dir /path/to/personpath22_json \
        --frames_dir data/frames \
        --out_file data/gt_coco.json
"""
import argparse
import json
from pathlib import Path
import cv2


def find_annotation_file(ann_dir: Path, video_stem: str):
    candidates = [
        ann_dir / f"{video_stem}.json",
        ann_dir / f"{video_stem}_mp4.json",
        ann_dir / f"{video_stem}.mp4.json",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--annotation_dir", required=True)
    ap.add_argument("--frames_dir", required=True)
    ap.add_argument("--out_file", required=True)
    args = ap.parse_args()

    ann_dir = Path(args.annotation_dir)
    frames_dir = Path(args.frames_dir)

    images = []
    annotations = []
    ann_id = 0
    image_id = 0
    image_map = {}  # (video_stem, frame_idx) -> image_id

    video_dirs = sorted([d for d in frames_dir.iterdir() if d.is_dir()])

    # Pass 1: build image records from extracted frames
    for vd in video_dirs:
        frame_paths = sorted(vd.glob("*.jpg"))
        if not frame_paths:
            continue
        # Get dimensions from first frame
        sample = cv2.imread(str(frame_paths[0]))
        h, w = sample.shape[:2]

        for fp in frame_paths:
            frame_idx = int(fp.stem.split("_f")[-1])
            image_id += 1
            images.append({
                "id": image_id,
                "file_name": f"{vd.name}/{fp.name}",
                "width": w,
                "height": h,
                "video": vd.name,
                "frame_idx": frame_idx,
            })
            image_map[(vd.name, frame_idx)] = image_id

    # Pass 2: read JSON annotations, keep only 'person' labels, align to extracted frames
    n_skipped_no_anno_file = 0
    n_skipped_not_person = 0
    n_skipped_frame_not_extracted = 0

    for vd in video_dirs:
        ann_file = find_annotation_file(ann_dir, vd.name)
        if ann_file is None:
            print(f"[WARN] No annotation file for {vd.name}")
            n_skipped_no_anno_file += 1
            continue

        with open(ann_file) as f:
            data = json.load(f)

        for e in data['entities']:
            # Keep only person labels
            if 'person' not in e.get('labels', {}):
                n_skipped_not_person += 1
                continue

            frame_idx = e['blob']['frame_idx']
            key = (vd.name, frame_idx)
            if key not in image_map:
                n_skipped_frame_not_extracted += 1
                continue

            x, y, bw, bh = e['bb']
            ann_id += 1
            annotations.append({
                "id": ann_id,
                "image_id": image_map[key],
                "category_id": 1,
                "bbox": [float(x), float(y), float(bw), float(bh)],
                "area": float(bw * bh),
                "iscrowd": 0,
            })

    coco = {
        "images": images,
        "annotations": annotations,
        "categories": [{"id": 1, "name": "person"}],
    }

    Path(args.out_file).parent.mkdir(parents=True, exist_ok=True)
    with open(args.out_file, "w") as f:
        json.dump(coco, f)

    print(f"\n=== Conversion complete ===")
    print(f"  Images: {len(images)}")
    print(f"  Annotations (person): {len(annotations)}")
    print(f"  Videos without annotation file: {n_skipped_no_anno_file}")
    print(f"  Non-person entities skipped: {n_skipped_not_person}")
    print(f"  Annotations for non-extracted frames (expected if partial): {n_skipped_frame_not_extracted}")
    print(f"\nSaved to {args.out_file}")


if __name__ == "__main__":
    main()