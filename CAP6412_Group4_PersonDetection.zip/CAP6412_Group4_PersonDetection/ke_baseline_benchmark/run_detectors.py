"""
Run person detection across YOLOv8, RT-DETR, and Faster R-CNN on extracted frames.
Outputs COCO-format predictions JSON for each detector.

Usage:
    python run_detectors.py --frames_dir /path/to/frames --out_dir /path/to/preds \
        --detector yolov8m  # or rtdetr, fasterrcnn
"""
import argparse
import json
import time
from pathlib import Path

import torch


PERSON_CLASS_COCO = 0  # "person" in COCO


def load_detector(name: str):
    """Returns (detector_object, inference_fn). inference_fn(img_path) -> list of dicts."""
    name = name.lower()

    if name in ("yolov8m", "yolov8s", "yolov8l", "yolov8x"):
        from ultralytics import YOLO
        model = YOLO(f"{name}.pt")

        def infer(img_path):
            results = model(img_path, classes=[PERSON_CLASS_COCO], verbose=False)
            r = results[0]
            out = []
            if r.boxes is None or len(r.boxes) == 0:
                return out
            boxes = r.boxes.xyxy.cpu().numpy()
            scores = r.boxes.conf.cpu().numpy()
            for (x1, y1, x2, y2), s in zip(boxes, scores):
                out.append({
                    "bbox": [float(x1), float(y1), float(x2 - x1), float(y2 - y1)],
                    "score": float(s),
                    "category_id": 1,  # COCO person in eval-side
                })
            return out
        return model, infer

    elif name == "rtdetr":
        from ultralytics import RTDETR
        model = RTDETR("rtdetr-l.pt")

        def infer(img_path):
            results = model(img_path, classes=[PERSON_CLASS_COCO], verbose=False)
            r = results[0]
            out = []
            if r.boxes is None or len(r.boxes) == 0:
                return out
            boxes = r.boxes.xyxy.cpu().numpy()
            scores = r.boxes.conf.cpu().numpy()
            for (x1, y1, x2, y2), s in zip(boxes, scores):
                out.append({
                    "bbox": [float(x1), float(y1), float(x2 - x1), float(y2 - y1)],
                    "score": float(s),
                    "category_id": 1,
                })
            return out
        return model, infer

    elif name == "fasterrcnn":
        import torchvision
        from torchvision.transforms import functional as F
        from PIL import Image

        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        model = torchvision.models.detection.fasterrcnn_resnet50_fpn(
            weights="DEFAULT"
        ).eval().to(device)

        def infer(img_path):
            img = Image.open(img_path).convert("RGB")
            tensor = F.to_tensor(img).to(device)
            with torch.no_grad():
                preds = model([tensor])[0]
            out = []
            boxes = preds["boxes"].cpu().numpy()
            scores = preds["scores"].cpu().numpy()
            labels = preds["labels"].cpu().numpy()
            for (x1, y1, x2, y2), s, lbl in zip(boxes, scores, labels):
                # torchvision Faster R-CNN COCO: class 1 == person
                if lbl != 1:
                    continue
                out.append({
                    "bbox": [float(x1), float(y1), float(x2 - x1), float(y2 - y1)],
                    "score": float(s),
                    "category_id": 1,
                })
            return out
        return model, infer

    else:
        raise ValueError(f"Unknown detector: {name}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--frames_dir", required=True,
                    help="Directory containing subfolders per video with .jpg frames")
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--detector", required=True,
                    choices=["yolov8m", "yolov8s", "yolov8l", "yolov8x", "rtdetr", "fasterrcnn"])
    ap.add_argument("--conf_thresh", type=float, default=0.25)
    args = ap.parse_args()

    frames_dir = Path(args.frames_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"Loading {args.detector}...")
    _, infer_fn = load_detector(args.detector)

    # Collect all frame paths
    video_dirs = sorted([d for d in frames_dir.iterdir() if d.is_dir()])
    all_predictions = []  # COCO-style list
    image_records = []    # For a COCO-images table

    image_id = 0
    total_frames = 0
    total_time = 0.0

    for vd in video_dirs:
        frame_paths = sorted(vd.glob("*.jpg"))
        print(f"[{vd.name}] {len(frame_paths)} frames")
        for fp in frame_paths:
            image_id += 1
            t0 = time.time()
            dets = infer_fn(str(fp))
            total_time += time.time() - t0
            total_frames += 1

            image_records.append({
                "id": image_id,
                "file_name": f"{vd.name}/{fp.name}",
                "video": vd.name,
            })

            for d in dets:
                if d["score"] < args.conf_thresh:
                    continue
                all_predictions.append({
                    "image_id": image_id,
                    "category_id": 1,
                    "bbox": d["bbox"],
                    "score": d["score"],
                })

    # Save
    out_file = out_dir / f"{args.detector}_predictions.json"
    with open(out_file, "w") as f:
        json.dump({
            "detector": args.detector,
            "images": image_records,
            "predictions": all_predictions,
            "fps": total_frames / total_time if total_time > 0 else 0,
            "total_frames": total_frames,
            "total_time_sec": total_time,
        }, f)

    print(f"\nSaved {len(all_predictions)} predictions across {total_frames} frames to {out_file}")
    print(f"Average FPS: {total_frames/total_time:.2f}" if total_time > 0 else "")


if __name__ == "__main__":
    main()